<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Feb. 7th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44

?>

@extends('layouts.app')
<style>
            html, body {
                background-image: linear-gradient(lightskyblue, powderblue);
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }</style>
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Update Group</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

								

                    <form action="{{ route('groups.update', $group->id) }}" method="POST">
                    
                    @csrf
                    
                    @method('PUT')
                    
                    <div class="form-group">
                    
                    	<label for="groupTitle">Group Title</label>
                    
                    	<input type="text" class="form-control" name="groupTitle" id="groupTitle" value="{{ $group->groupTitle }}">
                    
                    </div>
                    
                    <div class="form-group">
                    
                    	<label for="about">About</label>
                    
                    	<input type="text" class="form-control" name="about" id="about" value="{{ $group->about }}">
                    
                    </div>
                    
                    <div class="form-group">
                    
                    	<label for="rules">Rules</label>
                    
                    	<input type="text" class="form-control" name="rules" id="rules" value="{{ $group->rules }}">
                    
                    </div>
                    
                    <button type="submit" class="btn btn-success">Update</button>
                    
                    </form>                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
