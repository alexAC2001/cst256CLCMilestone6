<?php
// Alexander Carrillo & Jeanna Benitez

// CST - 256

// March 11th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.w3schools.com/css/tryit.asp?filename=trycss3_gradient-linear
// https://www.tutorialspoint.com/How-to-set-Text-alignment-in-HTML#:~:text=To%20set%20text%20alignment%20in%20HTML%2C%20use%20the%20style%20attribute,center%2C%20left%20and%20right%20alignment.
// https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_global_class2
?>
@extends('layouts.app')
<style>
            html, body {
                background-image: linear-gradient(lightskyblue, powderblue);
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }</style>
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Search for Jobs') }}</div>

                <div class="card-body">
                    <form method="GET" action= "{{ route('searchResults') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="searchJob" class="col-md-4 col-form-label text-md-right">{{ __('Job Title') }}</label>

                            <div class="col-md-6">
                                <input id="jobTitle" type="text" class="form-control @error('jobTitle') is-invalid @enderror" name="jobTitle" value="{{ old('jobTitle') }}" required autocomplete="jobTitle" autofocus>

                                @error('searchJob')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Search') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Here are the results') }}</div>
                <div class="card-body">
                <?php 
                $servername = "localhost";
                $username = "root";
                $password = "root";
                $database_name = "networkapp";                
                $connection = mysqli_connect($servername, $username, $password, $database_name);                
                $searchForTitle = $_GET['jobTitle'];
                //$searchForDescription = $_GET['jobDescription'];
                // select jobs from the database
                $sql_statement = "SELECT * 
                                  FROM jobs 
                                  WHERE jobTitle 
                                  LIKE '%{$searchForTitle}%' ";// && jobDescription LIKE '%$searchForDescription%'";
                $result = mysqli_query($connection, $sql_statement);
                //$row = mysqli_fetch_assoc($result);
                ?>
		@if($connection)
		
			<table class="table">
			
				<thead>
				
					<th>#</th>
					
					<th>Job Title</th>
					
					<th>Company Name</th>
					
					<th>Job Description</th>
					
					<th>Job Location</th>
					
					<th>Employment Type</th>
					
					<th>Applicants</th>
					
					</thead>
					
					<tbody>
					
						@foreach($jobs as $job)
						@if($row = mysqli_fetch_assoc($result))
						
					    	<tr>
					    	
					    	<td>
					    				<?php echo $row['id'] . "<br>"; ?>
						    </td>
						    			
						    <td> 
										 <?php echo $row['jobTitle'] . "<br>"; ?>
						    </td>
						    
						    <td>
						    			 <?php echo $row['companyName'] . "<br>"; ?>
						    </td>
						    
						    <td>
						    			 <?php echo $row['jobDescription'] . "<br>"; ?>
						    </td>		
						    
						    <td>	 
									 <?php echo $row['jobLocation'] . "<br>"; ?>
						    </td>		
						    
						    <td>
						    		<?php echo $row['employmentType'] . "<br>"; ?>	 
						    </td>								    
						    
						    <td>
						    		<?php echo $row['applicants'] . "<br>"; ?>
						    </td>
						    
						    <td>
						    
						    <form method="POST" action= "{{ route('apply', [$job->id]) }}">
                                
                                {{ csrf_field() }}
                                
                                <button type="submit" class="btn btn-success btn-sn">Apply</button>
                                
                            </form>	
                            
                            <form method="GET" action="{{ route('details', [$job->id]) }}">
                            
                                {{ csrf_field() }}
                                
                                <button type="submit" class="btn btn-success btn-sn">Details</button>
                            </form>
						    	
						    <td>
						    
						    </tr>
						    		 
					@endif
					@endforeach	
					</tbody>			
			
			</table>
			
		@else
			
			<h3 class="text-center">No Jobs Yet</h3>
			
		@endif

</div>
</div>
</div>
</div>
</div>
@endsection
