<?php
namespace App\Services\Data;

use App\Models\UserModel;
use Carbon\Exceptions\Exception;
use Illuminate\Support\Facades\Log;
use App\Job;
use App\User;

class SecurityDAO
{
    // Define the connection string
    private $conn;
    private $servername = "localhost";
    private $username = "root";
    private $password = "root";
    private $dbname = "networkapp";
    private $port = "";
    private $dbQuery;
    
    // Constructor that creates a connection with the database
    public function __construct()
    {
        // Create a connection to the database
        $this->conn = mysqli_connect($this->servername, $this->username, $this->password, $this->dbname);
        // Make sure to always test the connection and see if there are any errors. (Try catch?)
    }
    
    public function findByUser(UserModel $credentials)
    {
        try
        {
            // Define the query to search the database for the credentials
            $this->dbQuery = "SELECT Username, Password
                              FROM user
                              WHERE Username = '{$credentials->getUsername()}'
                              AND Password = '{$credentials->getPassword()}'";
            // If the selected query returns a resultset
            $result = mysqli_query($this->conn, $this->dbQuery);
            // If there are rows that are returned we have valid credentials
            if(mysqli_num_rows($result) > 0)
            {
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return true;
            }
            else 
            {
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return false;
            }
        
        } catch(Exception $e)
        {        
            Log::error("Exception in SecurityDAO" . $e->getMessage());
            echo $e->getMessage();
        }
    }
    
    // To find all jobs for rest api
    public function findAllJobs()
    {
        $server = "localhost";
        $username = "root";
        $password = "root";
        $database = "networkapp";
        $conn = mysqli_connect($server, $username, $password, $database);
        if(!$conn) {
            die("Connection Failed: " .mysqli_connect_error());
        }
        $sql = "SELECT * FROM jobs";
        $result = mysqli_query($conn, $sql);
        $jobs[Job::class] = array();
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $jobs[] = "<br>ID: " . $row['id'] . "<br>" . "Job Title: " . $row['jobTitle'] . "<br> " . "Company Name: " . 
                    $row['companyName'] . "<br>" . "Job Description: " . $row['jobDescription'] . "<br>" . "Job Location: " . 
                    $row['jobLocation'] . "<br>" . "Employment Type: " . $row['employmentType'] . "<br>" . "Applicants: " . 
                    $row['applicants'] . "<br>" . "--------";
            }
        } 
        return $jobs;
    }
    
    // Get a desired Job
    public function findJobById($id)
    {
        $server = "localhost";
        $username = "root";
        $password = "root";
        $database = "networkapp";
        $conn = mysqli_connect($server, $username, $password, $database);
        if(!$conn) {
            die("Connection Failed: " .mysqli_connect_error());
        }
        
        try
        {
            // Define the query to search the database for the credentials
            $dbQuery = "SELECT * FROM jobs
                              WHERE jobTitle = '$id'";
            // If the selected query returns a resultset
            $result = mysqli_query($conn, $dbQuery);
            // If there are rows that are returned we have valid credentials
            //if(mysqli_num_rows($result) > 0 && mysqli_num_rows($result) < 2)
            if($row = mysqli_fetch_assoc($result))
            {
                mysqli_free_result($result);
                echo "ID: " . $row['id'] . "<br>";
                echo "Job Title: " . $row['jobTitle'] . "<br>";
                echo "Company Name: " . $row['companyName'] . "<br>";
                echo "Job Description: " . $row['jobDescription'] . "<br>";
                echo "Job Location: " . $row['jobLocation'] . "<br>";
                echo "Employment Type " . $row['employmentType'] . "<br>";
                echo "Applicants: " . $row['applicants'] . "<br>";
                mysqli_close($this->conn);
                return true;
            }
            else
            {
                mysqli_free_result($result);
                echo "The Job does not exist";
                mysqli_close($this->conn);
                return false;
            }
            
        } catch(Exception $e)
        {
            echo $e->getMessage();
        }        
    }
    
    // Get a desired Member Profile
    public function findMemberById($id)
    {
        $server = "localhost";
        $username = "root";
        $password = "root";
        $database = "networkapp";
        $conn = mysqli_connect($server, $username, $password, $database);
        if(!$conn) {
            die("Connection Failed: " .mysqli_connect_error());
        }
        
        try
        {
            // Define the query to search the database for the credentials
            $dbQuery = "SELECT * FROM users
                              WHERE name = '$id'";
            // If the selected query returns a resultset
            $result = mysqli_query($conn, $dbQuery);
            // If there are rows that are returned we have valid credentials
            //if(mysqli_num_rows($result) > 0 && mysqli_num_rows($result) < 2)
            if($row = mysqli_fetch_assoc($result))
            {
                mysqli_free_result($result);
                echo "ID: " . $row['id'] . "<br>";
                echo "Name: " . $row['name'] . "<br>";
                echo "About Me: " . $row['about'] . "<br>";
                echo "Age: " . $row['age'] . "<br>";
                echo "Career Choice " . $row['careerChoice'] . "<br>";
                mysqli_close($this->conn);
                return true;
            }
            else
            {
                mysqli_free_result($result);
                echo "The User does not exist";
                mysqli_close($this->conn);
                return false;
            }
            
        } catch(Exception $e)
        {
            echo $e->getMessage();
        }
    }
    
}