<?php
namespace App\Services\Business;

//use App\Models\UserModel;
//use App\Models\CustomerModel;
use App\Services\Data\SecurityDAO;
//use App\Services\Data\CustomerDAO;
//use App\Services\Data\OrderDAO;
//use App\Services\Data\Utility\DBConnect;
class SecurityService 
{    
    // Get all Jobs
    public function getAllJobs() 
    {
        $this->getAllJobs = new SecurityDAO();
        return $this->getAllJobs->findAllJobs();
    }
    // Get a desired job
    public function getJob($id)
    {
        $this->getJob = new SecurityDAO();
        return $this->getJob->findJobById($id);
    }
    // Get a member profile
    public function getMember($id)
    {
        $this->getMember = new SecurityDAO();
        return $this->getMember->findMemberById($id);
    }   
}