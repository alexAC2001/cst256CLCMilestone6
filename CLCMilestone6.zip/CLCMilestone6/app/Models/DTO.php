<?php 
namespace App\Models;

use \JsonSerializable;
use PHPUnit\Util\Json;

class DTO implements \JsonSerializable
{
    // Variables for outputting messages for success or failuer
    private $code;
    private $message;
    private $data;
    
   
    // Class Constructor
    public function __construct($code, $message, $data)
    {
        $this->code = $code;
        $this->message = $message;
        $this->data = $data;
    }   
    
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
     /**
     * @return mixed
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @return mixed
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * @return mixed
     */
    public function getData()
    {
        return $this->data;
    }
}