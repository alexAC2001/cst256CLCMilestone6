<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Feb. 27th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44

// IMPORTANT

namespace App\Http\Controllers;

use App\Job;
use App\User;
use App\Group;
use App\Http\Requests\Users\UpdateProfileRequest;
use App\Http\Requests\Jobs\UpdateJobRequest;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Symfony\Component\Routing\Loader\Configurator\Traits\AddTrait;

class GroupsController extends Controller
{
    
    // This method DISPLAYS a page with all the users for the admin
    public function index()
    {
        return view('groups.index')->with('groups', Group::all());       
    }
    // For Admins to create new group
    public function create()
    {
        return view('groups.create');
    }
    // To DISPLAY all groups for anyone to see
    public function list()
    {
        return view('groups.list')->with('groups', Group::all());
    }    
    public function show(Job $id)
    {
        return view('jobs.index', ['job'=>id]);
    }
    
    // Request Group properties
    public function store()
    {
        $group = new Group;
        
        $group->groupTitle = request('groupTitle');
        $group->about = request('about');
        $group->rules = request('rules');
        $group->members = request('members');
        $group->save();
    }
    
    // To return edit view for a group
    public function edit($id)
    {
        // get the job
        $group = group::find($id);
        
        // show the edit form and pass the group
        return view('groups.edit')->with('group', $group);
    }
    
    // To update the group in the database
    public function update($id)
    {
        // validate
        // read more on validation at http://laravel.com/docs/validation
        $rules = array(
            'groupTitle'       => 'required',
            'about'      => 'required|about',
            'rules' => 'required|rules',
            //'employmentType' => 'required|employmentType'
        );
            // store
            $group = group::find($id);
            $group->groupTitle       = Input::get('groupTitle');
            $group->about      = Input::get('about');
            $group->rules = Input::get('rules');
            $group->save();            
            // redirect
            //Session::flash('message', 'Successfully updated ');
            return Redirect::to('groups.index');
    }
    
    // For Admin to delete an Affinity Group
    public function destroy($id)
    {
        // delete
        $group = group::find($id);
        $group->delete();
        
        // Redirect
        //Session::flash('message', 'Successfully deleted the job');
        return Redirect::to('groups.index');
    }
    // For Users/Admins to join an affinity group
    public function joinGroup($id)
    {
        // store
        $group = group::find($id);
        $user = auth()->user();
        
        //$user = //user::find($name);
        //$group->members = Input::get('members', $user->name);
        $group->members = Input::get('members', $user->name);
        $group->save();
        // redirect
        //Session::flash('message', 'Successfully updated ');
        return redirect()->back();
    }
    
    // For Users/Admins to leave an affinity group
    public function leaveGroup($id)
    {
        // store
        $group = group::find($id);        
        //$user = //user::find($name);
        $group->members = Input::get('members', '');
        $group->save();
        // redirect
        return redirect()->back();
    }
    
}
